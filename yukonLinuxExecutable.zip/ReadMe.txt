///// THIS README OFFERS INFORMATION ON HOW TO RUN THE STANDALONE ON LINUX /////

NOTE: The project WILL compile on Windows, and it will run, but it will crash as soon as the user attempts to load a deck of cards.


///// STANDALONE FOR LINUX /////

The standalone application is made to run on Linux.

To run the file on a Linux system follow these steps:

1. Unzip the folder yukonLinuxExecutable.zip to a location of your choice.
2. Navigate to the root of the created directory with your terminal.
3. In the terminal type "./yukon" without the quotes.

PS: It is very important that the folder "decks" is located in the same directory as the "yukon" file, in fact, the program will crash without it.